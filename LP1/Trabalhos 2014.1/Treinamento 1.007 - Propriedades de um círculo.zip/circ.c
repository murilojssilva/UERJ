#include <stdio.h>
#include <math.h>
#define PI 3.14159265358979
main()
{
	double r;
	printf("Base: \n");
	scanf("%lf",&r);
	if (r<0)
		printf("O RAIO NAO PODE SER NEGATIVO");
	else
		printf("%.2lf\n%.2lf",2*r*PI,PI*r*r);
}
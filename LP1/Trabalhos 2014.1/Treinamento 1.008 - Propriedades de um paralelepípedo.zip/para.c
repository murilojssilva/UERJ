#include <stdio.h>
#include <math.h>
#define PI 3.14159265358979
main()
{
	double L1,L2,L3;
	scanf("%lf",&L1);
	scanf("%lf",&L2);
	scanf("%lf",&L3);
	if (L1<0 || L2<0 || L3<0)
		printf("NENHUM LADO PODE SER NEGATIVO");
	else
		printf("%.2lf\n%.2lf\n%.2lf",2*(L1*L2+L1*L3+L2*L3),(L1*L2*L3),sqrt(pow(L1,2)+pow(L2,2)+pow(L3,2)));
}
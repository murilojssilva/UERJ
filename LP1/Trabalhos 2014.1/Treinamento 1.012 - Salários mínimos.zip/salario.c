#include<stdio.h>
double main()
{
    double M,S;
    scanf("%lf",&M);
    scanf("%lf",&S);
    if (M<=0)
        printf("O SALARIO MINIMO DEVE SER MAIOR QUE ZERO");
    else if (S<M)
        printf("O SALARIO DO FUNCIONARIO NAO PODE SER MENOR QUE O MINIMO");
    else
        printf("%.2lf",S/M);     
}
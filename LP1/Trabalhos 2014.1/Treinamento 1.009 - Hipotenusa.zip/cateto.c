#include <stdio.h>
#include <math.h>
#define PI 3.14159265358979
main()
{
	double L1,L2;
	scanf("%lf",&L1);
	scanf("%lf",&L2);
	if (L1<0 || L2<0)
		printf("NENHUM CATETO PODE SER NEGATIVO");
	else
		printf("%.2lf",sqrt(pow(L1,2)+pow(L2,2)));
}
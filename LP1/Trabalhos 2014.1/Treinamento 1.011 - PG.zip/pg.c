#include <stdio.h>
int main()
{
	int t,r,p,n;
	scanf("%d",&r);
	scanf("%d",&p);
	scanf("%d",&n);
	if (n<=0)
	{
		printf("A QUANTIDADE DE TERMOS DEVE SER MAIOR QUE ZERO");
	}
	else
	{
		t=p*(pow(r,(n-1)));
		printf("%d",t);
	}
}
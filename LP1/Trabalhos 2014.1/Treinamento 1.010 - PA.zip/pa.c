#include <stdio.h>
#include <math.h>
#define PI 3.14159265358979
main()
{
	int n,r,p;
	scanf("%d",&r);
	scanf("%d",&p);
	scanf("%d",&n);
	if (n<=0)
		printf("A QUANTIDADE DE TERMOS DEVE SER MAIOR QUE ZERO");
	else
		printf("%d",r*(n-1)+p);
}
#include <stdio.h>
main ()
{
	char S[3];
	gets(S);
	//	S[2]='\0';
	if (strcmp(S,"AC")==0)
		printf("Acre - Rio Branco");
	else if (strcmp(S,"AL")==0)
		printf("Alagoas - Maceio");
	else if (strcmp(S,"AP")==0)
		printf("Amapa - Macapa");
	else if (strcmp(S,"AM")==0)
		printf("Amazonas - Manaus");
	else if (strcmp(S,"BA")==0)
		printf("Bahia - Salvador");
	else if (strcmp(S,"CE")==0)
		printf("Ceara - Fortaleza");
	else if (strcmp(S,"DF")==0)
		printf("Distrito Federal - Brasilia");
	else if (strcmp(S,"ES")==0)
		printf("Espirito Santo - Vitoria");
	else if (strcmp(S,"GO")==0)
		printf("Goias - Goiania");
	else if (strcmp(S,"MA")==0)
		printf("Maranhao - Sao Luiz");
	else if (strcmp(S,"MT")==0)
		printf("Mato Grosso - Cuiaba");
	else if (strcmp(S,"MS")==0)
		printf("Mato Grosso do Sul - Campo Grande");
	else if (strcmp(S,"MG")==0)
		printf("Minas Gerais - Belo Horizonte");
	else if (strcmp(S,"PA")==0)
		printf("Para - Belem");
	else if (strcmp(S,"PB")==0)
		printf("Paraiba - Joao Pessoa");
	else if (strcmp(S,"PR")==0)
		printf("Parana - Curitiba");
	else if (strcmp(S,"PE")==0)
		printf("Pernambuco - Recife");
	else if (strcmp(S,"PI")==0)
		printf("Piaui - Terezina");
	else if (strcmp(S,"RJ")==0)
		printf("Rio de Janeiro - Rio de Janeiro");
	else if (strcmp(S,"RN")==0)
		printf("Rio Grande do Norte - Natal");
	else if (strcmp(S,"RS")==0)
		printf("Rio Grande do Sul - Porto Alegre");
	else if (strcmp(S,"RO")==0)
		printf("Rondonia - Porto Velho");
	else if (strcmp(S,"RR")==0)
		printf("Roraima - Boa Vista");
	else if (strcmp(S,"SC")==0)
		printf("Santa Catarina - Florianopolis");
	else if (strcmp(S,"SP")==0)
		printf("Sao Paulo - Sao Paulo");
	else if (strcmp(S,"SE")==0)
		printf("Sergipe - Aracaju");
	else if (strcmp(S,"TO")==0)
		printf("Tocantins - Palmas");
	else
		printf("ESTADO INVALIDO");
}
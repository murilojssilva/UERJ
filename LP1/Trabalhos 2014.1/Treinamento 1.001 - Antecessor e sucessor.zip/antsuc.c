#include<stdio.h>
int main()
{
    int num;
    printf("Digite um número inteiro: ");
    scanf("%d",&num);
    printf("\n%d\n%d",num-1,num+1);
}
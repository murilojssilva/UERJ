#include <stdio.h>
#include <math.h>
main()
{
	double l;
	printf("Base: \n");
	scanf("%lf",&l);
	if (l<0)
		printf("O LADO NAO PODE SER NEGATIVO");
	else
		printf("%.2lf\n%.2lf\n%.2lf",4*l,pow(l,2),l*sqrt(2));
}
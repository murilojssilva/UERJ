#include <stdio.h>
int main ()
{
	int c,l,r;
	scanf("%d",&c);
	scanf("%d",&l);
	scanf("%d",&r);
	if (c<=0||l<=0||r<=0)
		printf("AS PONTUACOES DEVEM SER MAIORES QUE ZERO");
	else if (c==r||c==l||r==l)
		printf("AS PONTUACOES DEVEM SER DIFERENTES");
	else if (c>l&&c>l&&l>r)
		printf("1o lugar - Camila\n2o lugar - Leandro\n3o lugar - Rodrigo");
	else if (c>l&&c>l&&l<r)
		printf("1o lugar - Rodrigo\n2o lugar - Camila\n3o lugar - Leandro");
	else if (l>r&&l>c&&r>c)
		printf("1o lugar - Leandro\n2o lugar - Rodrigo\n3o lugar - Camila");
	else if (l>r&&l>c&&r<c)
		printf("1o lugar - Leandro\n2o lugar - Camila\n3o lugar - Rodrigo");
	else if (r>l&&r>c&&l>c)
		printf("1o lugar - Rodrigo\n2o lugar - Leandro\n3o lugar - Camila");
	else if (r>l&&r>c&&l<c)
		printf("1o lugar - Rodrigo\n2o lugar - Camila\n3o lugar - Camila");
}
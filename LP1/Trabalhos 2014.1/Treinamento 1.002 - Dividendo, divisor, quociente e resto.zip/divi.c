#include <stdio.h>
main()
{
    int dividendo,divisor;
    printf("Digite o dividendo: \n");
    scanf("%d",&dividendo);
    printf("Digite o divisor");
    scanf("%d",&divisor);
    printf("\n%d\n%d\n%d\n%d",dividendo,divisor,dividendo/divisor,dividendo%divisor);
}
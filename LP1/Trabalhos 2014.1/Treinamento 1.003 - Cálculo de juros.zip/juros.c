#include <stdio.h>
#include <math.h>
main()
{
	float emp,juros;
	printf("Digite o valor dos juros: \n");
	scanf("%f.2",&emp);
	if (emp<0)
    	printf("O VALOR DO EMPRESTIMO NAO PODE SER NEGATIVO\n");
	else
	{
    	juros=emp*pow(1.05,6);
    	printf("\n%f",juros);
	}
}
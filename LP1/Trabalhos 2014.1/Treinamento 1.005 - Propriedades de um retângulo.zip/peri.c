#include <stdio.h>
#include <math.h>
main()
{
	double b,h;
	printf("Base: \n");
	scanf("%lf",&b);
	printf("Altura: \n");
	scanf("%lf",&h);
	if (h<0)
		printf("A ALTURA NAO PODE SER NEGATIVA");
	else if (b<0)
		printf("A BASE NAO PODE SER NEGATIVA");	
	else
			printf("%.2lf\n%.2lf\n%.2lf",(2*(b+h)),(b*h),pow(b*b+h*h,0.5));
}
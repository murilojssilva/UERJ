#include <stdio.h>
void inverte(char);
FILE *arq;
void main()
{
   char nome[100];
	char c;
	fscanf(stdin,"%s",nome);
	arq = fopen(nome,"r");
	inverte(getc(arq));
	fclose(arq);     
}
void inverte(char c)
{
	if(c != EOF)
	{
		inverte(getc(arq));
		putchar(c);
	}
}
